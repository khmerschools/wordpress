<!DOCTYPE html>
<html <?php language_attributes(); ?>>
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
        <!--<title><?php wp_title('|', true, 'right'); ?></title>-->	
        <meta name="viewport" content="width=device-width, initial-scale=1.0">        
        <!-- wordpress head functions -->
        <?php wp_head(); ?>
        <link href="<?php echo bloginfo('template_url'); ?>/css/bootstrap.css" type="text/css" rel="stylesheet"/>
        <style type="text/css">
            html,body{
                margin: 0!important;
                padding: 0!important;
            }
        </style>
    </head>
    <body>
        <h1>
            <?php
            echo get_option('my_theme_logo_text');
            ?>
        </h1>
        <div class="menu">
            <?php
            do_action('top_menu');
            ?>
        </div>
        <?php
//        echo do_action('do_sum', 20, 330);
        ?>
                