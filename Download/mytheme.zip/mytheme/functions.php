<?php
register_nav_menus(array(
    'top_menu' => 'This is top menu',
    'footer_menu' => 'This is footer menu'
));
// Register Custom Navigation Walker
require_once('wp_bootstrap_navwalker.php');

add_action('top_menu', 'get_nav_wordpress');

function get_nav_wordpress() {
    wp_nav_menu(array(
        'menu' => 'top_menu',
        'theme_location' => 'top_menu',
        'depth' => 2,
        'container' => 'div',
        'container_class' => 'collapse navbar-collapse',
        'container_id' => 'bs-example-navbar-collapse-1',
        'menu_class' => 'nav navbar-nav',
        'fallback_cb' => 'wp_bootstrap_navwalker::fallback',
        'walker' => new wp_bootstrap_navwalker())
    );
}

add_action('do_sum', 'sum', 20, 30);

function sum($val1, $val2) {
    echo $val1 + $val2;
}

add_action('widgets_init', 'register_widgets');

function register_widgets() {
    register_sidebar(array(
        'name' => 'Footer',
        'id' => 'footer_sidebar',
        'before_widget' => '<div class="widget">',
        'after_widget' => '</div>',
        'before_title' => '<h2 class="widget-title title">',
        'after_title' => '</h2>',
    ));
}

// Get widget
add_filter('widget_text', 'do_shortcode');
add_action('get_widget', 'get_widget', 'footer_sidebar');

function get_widget($id) {
    if (is_active_sidebar($id)) {
        dynamic_sidebar($id);
    }
}

// Shortcode hello world
add_shortcode('get_string', 'get_string');

function get_string() {
    return "Hello World";
}

// Shortcode sum value
add_shortcode('get_sum', 'sum_value');

function sum_value($attr) {
    $attr = extract(shortcode_atts(array(
        'val1' => 10,
        'val2' => 20,
                    ), $attr));
    return $attr['val1'] + $attr['val2'];
}

// Shortcode sum value
add_shortcode('display', 'display_string');

function display_string($attr, $content = '') {
    $attr = extract(shortcode_atts(array(
        'class' => 'item'
                    ), $attr));

    $html = '<div class="' . $attr['class'] . '">';
    $html.=$content;
    $html.='</div>';
    return $html;
}

// Theme options
add_action("admin_menu", "setup_theme_admin_menus");

function setup_theme_admin_menus() {
    add_menu_page('Theme settings', 'My Theme', 'manage_options', 'my_theme_settings', 'theme_settings_page');
    add_submenu_page('my_theme_settings', 'Theme Options', 'Theme Options', 'manage_options', 'theme-options', 'theme_front_page_settings');
}

function theme_front_page_settings() {
    echo "Hello, world!";
}

function theme_settings_page() {
    ?>
    <h2>Theme Options</h2>
    <?php
    saveOptions();
    $elements = get_option("my_theme_logo_text");
    
    $elements = empty($elements)?get_bloginfo():$elements;
    ?>
    <form method="POST" action="">
        <label for="logo_text">
            Logo Text: 
        </label>
        <input type="text" name="logo_text" value="<?php echo $elements; ?>" />
        <p>
            <input type="submit" value="Save" name="save-options" class="button-primary"/>
        </p>
    </form>
    <?php
}

function saveOptions() {
    if (isset($_POST["save-options"])) {
        $elements = esc_attr($_POST["logo_text"]);
        update_option("my_theme_logo_text", $elements);
        echo '<div id="message" class="updated">Settings saved</div>';
    }
}

// Check that the user is allowed to update options
//if (!current_user_can('manage_options')) {
//    wp_die('You do not have sufficient permissions to access this page.');
//}


 

