
<!--Sidebar-->
<div class="container">
    <div class="row">
        <div class='col-lg-4'>
            <?php
            do_action('get_widget','footer_sidebar');
            ?>
        </div>
    </div>
</div>

<div class="copyright">&copy;www.hschools.com 2014</div>
</body>
</html>



