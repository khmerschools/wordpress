<?php
// Get Header 
get_header();
?>
<div class="container">
    <?php
    if (have_posts()) :
        while (have_posts()) : the_post();
            ?>
            <h2 class="title"><?php the_title(); ?></h2>
            <div class="content">
                <?php the_content(); ?>
            </div>
            <?php
        endwhile;
    else :
        echo wpautop('Sorry, no posts were found');
    endif;
    ?>
</div>
<?php
//Get Footer
get_footer();
?>

<div class="col-lg-4">
    This is my first content!
</div>
<?php
//    echo do_shortcode('[get_string]');
//    echo '<br />';
//    echo do_shortcode('[get_sum val1="30" val2="40"]');
//    echo '<br />';
//    echo do_shortcode('[display class="col-lg-4"]'
//            . 'This is my first content![/display]');
?>


