<?php

/**
 * Plugin Name: Google Map Plugin
 * Plugin URI: http://khschools.com
 * Description: A google map wordpress plugin
 * Version: 1.0
 * Author: Khmer Schools
 * Author URI: http://khschools.com
 * License: Free to use and share
 */
function sql_install() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'googlemap';
    $sql = "CREATE  TABLE $table_name (
		id INT NOT NULL AUTO_INCREMENT ,
                title VARCHAR(250) NULL,
                url TEXT NULL ,
                PRIMARY KEY (id)
	) ENGINE = InnoDB;";
    $wpdb->query($sql);
}

register_activation_hook(__FILE__, 'sql_install');

function sql_uninstall() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'googlemap';
    $sql = "DROP TABLE {$table_name};";
    $wpdb->query($sql);
}

register_deactivation_hook(__FILE__, 'sql_uninstall');


// Register Menu and icon
add_action('admin_menu', 'register_my_custom_menu_page');

function register_my_custom_menu_page() {
    add_menu_page('Google Map Plugin', 'Google Map', 'manage_options', 'googlemap_plugin', 'googlemap_function', plugins_url('img/icon.png', __FILE__));
    add_submenu_page('googlemap_plugin', 'Add New', 'Add New', 'manage_options', 'add_new_google_map', 'add_googlemap_function');
}

function add_googlemap_function() {
    include_once 'includes/add.php';
}

function googlemap_function() {
    include_once 'includes/index.php';
}

// Register style
add_action('admin_init', 'register_style');

function register_style() {
    /* Register our stylesheet. */
    wp_register_style('myPluginStylesheet', plugins_url('css/style.css', __FILE__));
    wp_enqueue_style('myPluginStylesheet');
}

// Register style
add_action('admin_init', 'register_script');

function register_script() {
    /* Register our stylesheet. */
    wp_register_script('myPluginScript', plugins_url('js/script.js', __FILE__));
    wp_enqueue_script('myPluginScript');
}

add_shortcode('location', 'get_location');
function get_location($attr) {
    $attr = extract(shortcode_atts(array(
        'id' => '10'
                    ), $attr));
    $html = '';
    global $wpdb;
    $table_name = $wpdb->prefix . 'googlemap';
    $sql = 'SELECT * FROM ' . $table_name.""
            . "WHERE id = $id";
    $locations = $wpdb->get_results($sql);
    foreach($locations as $loc){
        $html.=$loc->url;
    }
    return $html;
}

// add buttons to tinyMCE editor
add_action('init', 'register_icon');
function register_icon() {
    add_filter('mce_external_plugins', 'icon_add_button');
    add_filter('mce_buttons', 'icon_register_button');
}
// add button action script
function icon_add_button($plugin_array) {
    $plugin_array['googlemap_button'] = plugins_url('js/register-icon.js', __FILE__);
    return $plugin_array;
}

// register button in editor
function icon_register_button($buttons) {
    $buttons[] =  'googlemap_button';
    return $buttons;
}
