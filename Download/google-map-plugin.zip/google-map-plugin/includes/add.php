<?php
if (isset($_POST['save'])) {
    $title = mysql_real_escape_string($_POST['title']);
    $url = mysql_real_escape_string($_POST['url']);

    global $wpdb;
    $table_name = $wpdb->prefix . 'googlemap';
    $newLocation = $wpdb->insert(
            $table_name, array(
        'title' => $title,
        'url' => $url
            ), array('%s', '%s')
    );
    if ($newLocation) {
        ?>
        <div id = "message" class= "updated below-h2">
            <p>Data saved!</p>
        </div>
        <?php
    } else {
        ?>
        <div id = "message" class = "error">
            <p>Data not saved!</p>
        </div>
        <?php
    }
}
?>


<div class="wrap">
    <h1 class="title">Add New Location</h1>
    <form action="" method="POST">
        <label for="title">Title</label>
        <input type="text" name="title" id="title" />

        <label for="url">Url</label>
        <textarea name="url" id="url"></textarea><br />
        <input type="submit" name="save" value="Save" class="button button-primary button-large" />
    </form>
</div>