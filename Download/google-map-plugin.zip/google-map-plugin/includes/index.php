<?php
global $wpdb;
$table_name = $wpdb->prefix . 'googlemap';
$sql = 'SELECT * FROM ' . $table_name;
$locations = $wpdb->get_results($sql);
?>
<div class="wrap">
    <h1 class="title">Google Map Plugin</h1>

    <table class="mytable">
        <tr>
            <th width="30"><input type="checkbox" name="all" /></th>
            <th>ID</th>
            <th>Title</th>
            <th>Shortcode</th>
        </tr>
        <?php
        foreach ($locations as $loc) {
            ?>
            <tr>
                <td class="text-center">
                    <input type="checkbox" class="check" 
                           name="check[]" 
                           value="<?php echo $loc->id; ?>"/>
                </td>
                <td><?php echo $loc->id; ?></td>
                <td><?php echo $loc->title; ?></td>
                <td><?php echo '[location id ="' . $loc->id . '"]'; ?></td>
            </tr>
            <?php
        }
        ?>

    </table>
</div>