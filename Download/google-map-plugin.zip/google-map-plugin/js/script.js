jQuery(document).ready(function() {
    jQuery('input[name=all]').click(function() {
        if (jQuery(this).is(':checked')) {
            jQuery('.check').each(function() {
                this.checked = true;
            });
        } else {
            jQuery('.check').each(function() {
                this.checked = false;
            });
        }
    });
});

